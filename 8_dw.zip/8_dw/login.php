<?php
session_start();
$host = "localhost";
$user = "root";
$password = "";
$db = "8dw";


$data = mysqli_connect($host, $user, $password, $db);

if ($data == false) {
    die("Connection Error");
} else {
    echo 'Data Base Connect SuccessFully';
}
if(isset($_SESSION["username"]))
{
         header("location:adminhome.php");
}
else
{

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    # code...
    $username = $_POST["username"];
    $password = $_POST["pass"];
    $query = mysqli_fetch_array(mysqli_query($data,"select * from master_user_data where username='$username' and password='$password'"));
    if($query)
    {
        $_SESSION['username'] = $query[3];
        $_SESSION['uid'] = $query[0];
        header("location:userhome.php");
    }
    else {
        echo "username or password incorrect";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin and User Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.3/css/bulma.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />

    <link rel="stylesheet" href="./css/login.css">
</head>

<body>
    <div class="container kaso">
        <div class="bahahah is-flex is-justify-content-center">
            <div class="card ssp">
                <div class="card-content">
                    <div class="content">
                        <form action="#" method="post">
                            <input class="input" type="text" placeholder="Enter your Username" name="username">
                            <input class="input mt-4" type="password" placeholder="Enter your Password" name="pass">
                            <div class="buttons pt-3">
                                <button class="button is-primary is-fullwidth" type="submit">
                                    <i class="fas fa-sign-in-alt mr-3"></i>
                                    Login</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
<?php } ?>