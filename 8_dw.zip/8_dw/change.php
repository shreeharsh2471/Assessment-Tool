<?php

session_start();
if (isset($_SESSION['username'])) {
    # code...
    // Connect Database
    $mysql = mysqli_connect("localhost", "root", "", "8dw") or die(mysqli_connect_error());

    mysqli_select_db($mysql, '8dw') or die("Sorry No Database ");


    $rel = mysqli_query($mysql, "select * from master_user_data");
}

$que = mysqli_query($mysql, "Update master_user_data set Active='".$_POST['val']."' where id='".$_POST['id']."'");
if ($que) {
    # code...
    $q = mysqli_query($mysql, "select * from master_user_data where id='".$_POST['id']."'");
    $data = mysqli_fetch_assoc($que);
    echo $data['Active'];
}
?>