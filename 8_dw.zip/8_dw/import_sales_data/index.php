<?php
$con=mysqli_connect('localhost','root','','8dw');
if(isset($_POST['submit'])){
	$file=$_FILES['doc']['tmp_name'];
	
	$ext=pathinfo($_FILES['doc']['name'],PATHINFO_EXTENSION);
	if($ext=='xlsx'){
		require('PHPExcel/PHPExcel.php');
		require('PHPExcel/PHPExcel/IOFactory.php');
		
		
		$obj=PHPExcel_IOFactory::load($file);
		foreach($obj->getWorksheetIterator() as $sheet){
			$getHighestRow=$sheet->getHighestRow();
			for($i=0;$i<=$getHighestRow;$i++){
				$Date=$sheet->getCellByColumnAndRow(0,$i)->getValue();
				$Name=$sheet->getCellByColumnAndRow(1,$i)->getValue();
				$Phone=$sheet->getCellByColumnAndRow(2,$i)->getValue();
				$Email=$sheet->getCellByColumnAndRow(3,$i)->getValue();
				$Transaction_Id=$sheet->getCellByColumnAndRow(4,$i)->getValue();
				$Invoice_Value=$sheet->getCellByColumnAndRow(5,$i)->getValue();
				$Status	=$sheet->getCellByColumnAndRow(6,$i)->getValue();
				$Currency	=$sheet->getCellByColumnAndRow(7,$i)->getValue();
				$Credits	=$sheet->getCellByColumnAndRow(8,$i)->getValue();
				$Promo_Code=$sheet->getCellByColumnAndRow(9,$i)->getValue();
				$Promo_Discount=$sheet->getCellByColumnAndRow(10,$i)->getValue();
				$Channel	=$sheet->getCellByColumnAndRow(11,$i)->getValue();
				$Place_of_Supply	=$sheet->getCellByColumnAndRow(12,$i)->getValue();
				$Items=$sheet->getCellByColumnAndRow(13,$i)->getValue();
				$Order_Id=$sheet->getCellByColumnAndRow(14,$i)->getValue();
				$Payment_Mode=$sheet->getCellByColumnAndRow(15,$i)->getValue();
				$Invoice_No=$sheet->getCellByColumnAndRow(16,$i)->getValue();
				$Learner_GST=$sheet->getCellByColumnAndRow(17,$i)->getValue();
				$Affiliate_Code=$sheet->getCellByColumnAndRow(18,$i)->getValue();
				$GSTIN=$sheet->getCellByColumnAndRow(19,$i)->getValue();
				$Taxable_Value=$sheet->getCellByColumnAndRow(20,$i)->getValue();
				$Country_Code=$sheet->getCellByColumnAndRow(21,$i)->getValue();
				$IGST=$sheet->getCellByColumnAndRow(22,$i)->getValue();
				$CGST=$sheet->getCellByColumnAndRow(23,$i)->getValue();
				$SGST=$sheet->getCellByColumnAndRow(24,$i)->getValue();
				$VAT=$sheet->getCellByColumnAndRow(25,$i)->getValue();



				if($Email!=''){
					mysqli_query($con,"insert into sales_data(Date,Name,Phone,Email,Transaction_Id,Invoice_Value,Status,Currency,Credits,Promo_Code,Promo_Discount,Channel,Place_of_Supply,Items,Order_Id,Payment_Mode,Invoice_No,Learner_GST,Affiliate_Code,GSTIN,Taxable_Value,Country_Code,IGST,CGST,SGST,VAT) values('$Date','$Name','$Phone','$Email','$Transaction_Id','$Invoice_Value','$Status','$Currency','$Credits','$Promo_Code','$Promo_Discount','$Channel','$Place_of_Supply','$Items','$Order_Id','$Payment_Mode','$Invoice_No','$Learner_GST','$Affiliate_Code','$GSTIN','$Taxable_Value','$Country_Code','$IGST','$CGST','$SGST','$VAT')");
				}
			}
		}
	}else{
		echo "Invalid file format";
	}
}
?>
<form method="post" enctype="multipart/form-data">
	<input type="file" name="doc"/>
	<input type="submit" name="submit"/>
</form>