<?php
$con=mysqli_connect('localhost','root','','8dw');
if(isset($_POST['submit'])){
	$file=$_FILES['doc']['tmp_name'];
	
	$ext=pathinfo($_FILES['doc']['name'],PATHINFO_EXTENSION);
	if($ext=='xlsx'){
		require('PHPExcel/PHPExcel.php');
		require('PHPExcel/PHPExcel/IOFactory.php');
		
		
		$obj=PHPExcel_IOFactory::load($file);
		foreach($obj->getWorksheetIterator() as $sheet){
			$getHighestRow=$sheet->getHighestRow();
			for($i=0;$i<=$getHighestRow;$i++){
				$Created_On=$sheet->getCellByColumnAndRow(0,$i)->getValue();
				$Last_Login=$sheet->getCellByColumnAndRow(1,$i)->getValue();
				$Name=$sheet->getCellByColumnAndRow(2,$i)->getValue();
				$Email=$sheet->getCellByColumnAndRow(3,$i)->getValue();
				$Role=$sheet->getCellByColumnAndRow(4,$i)->getValue();
				$Mobile=$sheet->getCellByColumnAndRow(5,$i)->getValue();
				$Source=$sheet->getCellByColumnAndRow(6,$i)->getValue();
				$Refer_Code	=$sheet->getCellByColumnAndRow(7,$i)->getValue();
				$UTM_Source	=$sheet->getCellByColumnAndRow(8,$i)->getValue();
				$Segment	=$sheet->getCellByColumnAndRow(9,$i)->getValue();
				$Lead_Status=$sheet->getCellByColumnAndRow(10,$i)->getValue();
				$User_Notes	=$sheet->getCellByColumnAndRow(11,$i)->getValue();
				$Referral_Code_Used	=$sheet->getCellByColumnAndRow(12,$i)->getValue();
				$Credits=$sheet->getCellByColumnAndRow(13,$i)->getValue();


				if($Name!=''){
					mysqli_query($con,"insert into lms_data(Created_On,Last_Login,Name,Email,Role,Mobile,Source,Refer_Code,UTM_Source,Segment,Lead_Status,User_Notes,Referral_Code_Used,Credits) values('$Created_On','$Last_Login','$Name','$Email','$Role','$Mobile','$Source','$Refer_Code','$UTM_Source','$Segment','$Lead_Status','$User_Notes','$Referral_Code_Used','$Credits')");
				}
			}
		}
	}else{
		echo "Invalid file format";
	}
}
?>
<form method="post" enctype="multipart/form-data">
	<input type="file" name="doc"/>
	<input type="submit" name="submit"/>
</form>