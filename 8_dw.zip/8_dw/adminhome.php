<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN DASHBOARD</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.3/css/bulma.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />

</head>

<body>
    <!-- Navbar Code Start Here -->
    <nav class="navbar" role="navigation" aria-label="main navigation">
        <div class="navbar-brand">
            <a role="button" class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
            </a>
        </div>

        </div>
        </div>

        <div class="navbar-end">
            <div class="navbar-item">
                <div class="buttons">
                    <a class="button is-primary">
                        <strong>Sign up</strong>
                    </a>
                    <a class="button is-light">
                        Log in
                    </a>
                </div>
            </div>
        </div>
        </div>
    </nav>
    <hr class="mt-0">
    <!-- End Here -->

    <div class="container">
        <div class="is-flex is-justify-content-center">
            <div>
                <div class="box has-background-link	">
                    <h2 class="has-text-white">
                        Update LMS Data
                    </h2>
                    <a href="./Update_lms_data.php" class="button is-primary is-light mt-3">
                        Update LMS Data
                    </a>
                </div>
            </div>
            <div class="pl-5">
                <div class="box">
                    <h1>
                        Update Sale Data
                    </h1>
                    <a href="./Update_sales_data.php" class="button is-primary is-light mt-3">
                        Update Sale Data
                    </a>


                </div>
            </div>
        </div>
        <?php
        session_start();
        if (isset($_SESSION['username'])) {
            # code...
            // Connect Database
            $mysql = mysqli_connect("localhost", "root", "", "8dw") or die(mysqli_connect_error());

            mysqli_select_db($mysql, '8dw') or die("Sorry No Database ");


            $rel = mysqli_query($mysql, "select * from master_user_data");
        }


        ?>


        <!-- Select Items -->
        <form action="" method="post">

            <table class="is-fullwidth table is-bordered mt-5">
                <th>
                    UserName
                </th>
                <th>
                    Email addres
                </th>
                <th>
                    Change Status
                </th>
                <th>
                    Physical
                </th>
                <?php
                while ($row = mysqli_fetch_assoc($rel)) {
                    $options = $row['Active'];
                    $poptions = $row['Department_Code'];
                ?>
                    <tr>
                        <td>
                            <?php
                            echo $row['username'];
                            ?>

                        </td>
                        <td>
                            <?php
                            echo $row['email'];
                            ?>
                        </td>

                        <?php
                        //if ($row['Active'] == 1) {
                        # code...
                        // echo "<p id=str" . $row['id'] . "> Active </p>";
                        //} else {
                        // echo "<p id=str" . $row['id'] . "> Deactive </p>";
                        // }
                        ?>
                        <script>
                            function physical_del(pvalue, pid) {
                                $.ajax({
                                    type: 'post',
                                    url: "checkbox.php",
                                    data: {
                                        pvalue: pvalue,
                                        pid: pid
                                    },
                                    success: function(result) {
                                        if (result == 1) {
                                            $('#stri' + pid).html('Yes');
                                        } else {
                                            $('#stri' + pid).html('No');
                                        }
                                    }
                                });
                            }
                        </script>
                        <td class="is-fullwidth">
                            <select name="" id="" class="select is-fullwidth" onchange="active_deactive(this.value, <?php echo $row['id']; ?>) ">
                                <option value="1" <?php if ($options == "Active") echo 'selected="selected"'; ?>>Active</option>
                                <option value="0">Deactive</option>
                            </select>
                        </td>
                     
                    </tr>
                <?php

                }
                ?>
            </table>
            <button class="button is-primary" type="submit" name="activeusers">Submit Data</button>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
    <script>
        function active_deactive(val, id) {
            $.ajax({
                type: 'post',
                url: "change.php",
                data: {
                    val: val,
                    id: id
                },
                success: function(res) {
                    if (res == 1) {
                        $('#str' + id).html('Active');
                    } else {
                        $('#str' + id).html('Deactive');
                    }
                }
            });
        }
    </script>

</body>

</html>