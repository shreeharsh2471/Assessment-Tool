<!DOCTYPE html>
<?php
$conn=mysqli_connect("localhost","root","") or die("Could not connect");
mysqli_select_db($conn,"8dw") or die("could not connect database");

if(!isset($_SESSION)) 
	session_start();

$user_id = 0;
if(isset($_POST["user_id"])){
	$user_id = $_POST["user_id"];
}


if(isset($_POST["start"])){
	$_SESSION["user_id"] = $_POST["user_id"];
	$_SESSION["course_code"] = $_POST["course_code"];
	$_SESSION["dim_code"] = $_POST["dim_code"];
	$_SESSION["question_no"] = 0;


	header("location: quiz.php");
}


?>

<style>
	select{
		width: 350px;
	}
	table{
		width: 80%;
	}
</style>
<html lang="en">
<body>

<table>
<tr>
	<th>User: </th>
	<td>
	<form action="" method="POST">

		<select name="user_id" onchange="this.form.submit()">
			<?php
				echo '<option value="0">Select User</option>';
			$users = mysqli_query($conn, "SELECT * FROM `master_user_data` WHERE 1");
			while($user = mysqli_fetch_assoc($users)){
				$sel = " ";
				if($user_id == $user['id'])
					$sel = " selected ";

				echo '<option value="'.$user['id'].'" '.$sel.'>'.$user['Name'].'</option>';
			}
			?>
		</select>
	</form>
	</td>
</tr>

<?php
if($user_id == 0)
{
	return;
}

// $cur_user = mysqli_query($conn, "SELECT * FROM `master_user_data` WHERE id = '$user_id'");
// $cur_user = mysqli_fetch_assoc($cur_user);

?>

<form action="" method="POST">
	<input type="hidden" name="user_id" value="<?php echo $user_id ?>">
<tr>
	<th>Course: </th>
	<td>
	<select name="course_code" required>
		<?php
		$courses = mysqli_query($conn, "SELECT * FROM `8dw_m_course`");
		while($course = mysqli_fetch_assoc($courses)){
			echo '<option value="'.$course['course_code'].'">'.$course['course_name'].'</option>';
		}
		?>
	</select>
	</td>
</tr>
<tr>
	<th>Dimenstion: </th>
	<td>
	<select name="dim_code" required>
		<?php
		$dims = mysqli_query($conn, "SELECT * FROM `8dw_m_dimensions`");
		while($dim = mysqli_fetch_assoc($dims)){
			echo '<option value="'.$dim['dim_code'].'">'. $dim['dim_code'] . " - " . $dim['dim_name'].'</option>';
		}
		?>
	</select>
	</td>
</tr>

<tr>
	<td></td>
	<td>
		<input type="submit" value="Start" name="start">
	</td>
</tr>
</form>
</table>

</body>
</html>