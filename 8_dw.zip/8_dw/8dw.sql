-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2021 at 03:55 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `india`
--

-- --------------------------------------------------------

--
-- Table structure for table `8dw_m_accesstypes`
--

CREATE TABLE `8dw_m_accesstypes` (
  `access_code` int(2) NOT NULL,
  `access` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `8dw_m_accesstypes`
--

INSERT INTO `8dw_m_accesstypes` (`access_code`, `access`) VALUES
(1, 'FREE BASIC'),
(2, 'FREE ADVANCED'),
(3, 'FREE BOTH'),
(4, 'PAID BASIC'),
(5, 'PAID ADVANCED'),
(6, 'PAID BOTH');

-- --------------------------------------------------------

--
-- Table structure for table `8dw_m_answers`
--

CREATE TABLE `8dw_m_answers` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `max_score` int(11) NOT NULL,
  `min_score` int(11) NOT NULL,
  `cur_score` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `8dw_m_answers`
--

INSERT INTO `8dw_m_answers` (`id`, `user_id`, `question_id`, `max_score`, `min_score`, `cur_score`) VALUES
(1, 30, 1, 7, 4, 7),
(2, 30, 8, 10, 1, 10),
(4, 30, 2, 9, 0, 9),
(5, 30, 3, 10, 0, 10),
(6, 30, 4, 5, 2, 5),
(7, 30, 5, 7, 6, 7),
(8, 30, 6, 8, 0, 6),
(9, 30, 7, 10, 0, 4),
(10, 53, 1, 2, 1, 2),
(11, 53, 2, 2, 0, 2),
(12, 53, 3, 2, 1, 2),
(13, 53, 4, 2, 0, 2),
(14, 53, 5, 2, 1, 2),
(15, 53, 6, 2, 0, 2),
(16, 53, 7, 2, 0, 2),
(17, 53, 8, 2, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `8dw_m_course`
--

CREATE TABLE `8dw_m_course` (
  `course_code` varchar(10) NOT NULL,
  `course_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `8dw_m_course`
--

INSERT INTO `8dw_m_course` (`course_code`, `course_name`) VALUES
('A01', 'Advanced Course on Emotional Wellness'),
('A02', 'Advanced Course on Physical Wellness'),
('A03', 'Advanced Course on Social Wellness'),
('A04', 'Advanced Course on Occupational Wellness'),
('A05', 'Advanced Course on Financial Wellness'),
('A06', 'Advanced Course on Environmental Wellness'),
('A07', 'Advanced Course on Intellectual Wellness'),
('A08', 'Advanced Course on Spiritual Wellness'),
('F01', 'Foundation Course on the 8 Dimensions of Wellness'),
('M01', 'MasterCourse # 1'),
('M02', 'MasterCourse # 2');

-- --------------------------------------------------------

--
-- Table structure for table `8dw_m_dept`
--

CREATE TABLE `8dw_m_dept` (
  `dpt_code` int(2) NOT NULL,
  `dpt_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `8dw_m_dept`
--

INSERT INTO `8dw_m_dept` (`dpt_code`, `dpt_name`) VALUES
(1, 'Leadership'),
(2, 'Sales'),
(3, 'Marketing'),
(4, 'Operations'),
(5, 'Legal'),
(6, 'Finance'),
(7, 'Human Resources'),
(8, 'Administration'),
(9, 'Information Technology'),
(10, 'Research & Development'),
(99, 'Others');

-- --------------------------------------------------------

--
-- Table structure for table `8dw_m_dimensions`
--

CREATE TABLE `8dw_m_dimensions` (
  `dim_code` varchar(5) NOT NULL,
  `dim_name` varchar(30) NOT NULL,
  `dim_image` varchar(50) NOT NULL,
  `dim_color` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `8dw_m_dimensions`
--

INSERT INTO `8dw_m_dimensions` (`dim_code`, `dim_name`, `dim_image`, `dim_color`) VALUES
('D1', 'Emotional Wellness', '', ''),
('D2', 'Physical Wellness', '', ''),
('D3', 'Social Wellness', '', ''),
('D4', 'Occupational Wellness', '', ''),
('D5', 'Financial Wellness', '', ''),
('D6', 'Environmental Wellness', '', ''),
('D7', 'Intellectual Wellness', '', ''),
('D8', 'Spiritual Wellness', '', ''),
('', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `8dw_m_org`
--

CREATE TABLE `8dw_m_org` (
  `org_code` varchar(10) NOT NULL,
  `org_name` varchar(50) NOT NULL,
  `org_add` varchar(60) NOT NULL,
  `org_city` varchar(25) NOT NULL,
  `org_state` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `8dw_m_questions`
--

CREATE TABLE `8dw_m_questions` (
  `id` int(11) NOT NULL,
  `dim_code` varchar(10) NOT NULL,
  `qgrp_code` int(2) NOT NULL,
  `question_order` int(2) NOT NULL,
  `question` varchar(100) NOT NULL,
  `course_code` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `8dw_m_questions`
--

INSERT INTO `8dw_m_questions` (`id`, `dim_code`, `qgrp_code`, `question_order`, `question`, `course_code`) VALUES
(1, 'D1', 1, 1, 'Question 1', 'A01'),
(2, 'D1', 1, 2, 'Q 2', 'A01'),
(3, 'D1', 1, 3, 'Q3', 'A01'),
(4, 'D1', 1, 4, 'Q4', 'A01'),
(5, 'D1', 1, 5, 'Q5', 'A01'),
(6, 'D1', 1, 6, 'Q6', 'A01'),
(7, 'D1', 1, 7, 'Q7', 'A01'),
(8, 'D1', 1, 8, 'Q8', 'A01');

-- --------------------------------------------------------

--
-- Table structure for table `8dw_m_qust_grp`
--

CREATE TABLE `8dw_m_qust_grp` (
  `qgrp_code` int(2) NOT NULL,
  `qgrp_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `8dw_m_qust_grp`
--

INSERT INTO `8dw_m_qust_grp` (`qgrp_code`, `qgrp_name`) VALUES
(1, 'Emotional Wellness'),
(2, 'Physical Wellness'),
(3, 'Social Wellness'),
(4, 'Occupational Wellness'),
(5, 'Financial Wellness'),
(6, 'Environmental Wellness'),
(7, 'Intellectual Wellness'),
(8, 'Spiritual Wellness');

-- --------------------------------------------------------

--
-- Table structure for table `daily_logs`
--

CREATE TABLE `daily_logs` (
  `Timestamp` date NOT NULL,
  `LName_of_Lms` varchar(255) NOT NULL,
  `LName_of_Sale` varchar(255) NOT NULL,
  `LEmail_of_Lms` varchar(255) NOT NULL,
  `LEmail_of_Sale` varchar(255) NOT NULL,
  `LMobile_of_Lms` int(10) NOT NULL,
  `LMobile_of_Sale` int(10) NOT NULL,
  `Tot_Count_Lms_Data` int(255) NOT NULL,
  `Tot_Count_Sale_Data` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `lms_data`
--

CREATE TABLE `lms_data` (
  `id` int(11) NOT NULL,
  `Created_On` varchar(255) NOT NULL,
  `Last_Login` varchar(255) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Role` varchar(100) NOT NULL,
  `Mobile` varchar(10) NOT NULL,
  `Source` varchar(200) NOT NULL,
  `Refer_Code` varchar(200) NOT NULL,
  `UTM_Source` varchar(200) NOT NULL,
  `Segment` varchar(200) NOT NULL,
  `Lead_Status` varchar(200) NOT NULL,
  `User_Notes` varchar(200) NOT NULL,
  `Referral_Code_Used` varchar(200) NOT NULL,
  `Credits` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Triggers `lms_data`
--
DELIMITER $$
CREATE TRIGGER `insert_user` AFTER INSERT ON `lms_data` FOR EACH ROW INSERT INTO master_user_data(Name,Email) VALUES(new.Name, new.Email)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `master_user_data`
--

CREATE TABLE `master_user_data` (
  `id` int(10) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'Customer',
  `Picture` varchar(255) CHARACTER SET latin1 NOT NULL,
  `username` varchar(255) CHARACTER SET latin1 NOT NULL,
  `password` varchar(255) CHARACTER SET latin1 NOT NULL,
  `Name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `email` varchar(255) CHARACTER SET latin1 NOT NULL,
  `DOB` date NOT NULL,
  `Age` int(100) NOT NULL,
  `Gender` varchar(100) NOT NULL,
  `Phone_no` int(10) NOT NULL,
  `Oraganization_Code` varchar(255) NOT NULL,
  `Department_Code` varchar(255) NOT NULL,
  `Dim_code_1` varchar(255) NOT NULL,
  `Dim_code_2` varchar(255) NOT NULL,
  `Dim_code_3` varchar(255) NOT NULL,
  `Dim_code_4` varchar(255) NOT NULL,
  `Dim_code_5` varchar(255) NOT NULL,
  `Dim_code_6` varchar(255) NOT NULL,
  `Dim_code_7` varchar(255) NOT NULL,
  `Dim_code_8` varchar(255) NOT NULL,
  `Active` varchar(10) NOT NULL,
  `Rating` varchar(10) NOT NULL,
  `Access_code_basic` varchar(255) NOT NULL,
  `Access_code_adv` varchar(255) NOT NULL,
  `User_Type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `master_user_data`
--

INSERT INTO `master_user_data` (`id`, `role`, `Picture`, `username`, `password`, `Name`, `email`, `DOB`, `Age`, `Gender`, `Phone_no`, `Oraganization_Code`, `Department_Code`, `Dim_code_1`, `Dim_code_2`, `Dim_code_3`, `Dim_code_4`, `Dim_code_5`, `Dim_code_6`, `Dim_code_7`, `Dim_code_8`, `Active`, `Rating`, `Access_code_basic`, `Access_code_adv`, `User_Type`) VALUES
(53, 'Admin', '61559e4ace076-image.png', 'Admin', '1234562', 'Harsh', 'ss247@gmail.com', '2021-09-01', 20, 'Male', 20, '123', '1234', 'Applicable', 'Not Applicable', '', '', 'Applicable', '', '', '', 'Yes', '', 'Yes', 'No', 'Individual');

-- --------------------------------------------------------

--
-- Table structure for table `sales_data`
--

CREATE TABLE `sales_data` (
  `Date` varchar(255) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Phone` varchar(10) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Transaction_Id` varchar(255) NOT NULL,
  `Invoice_Value` varchar(255) NOT NULL,
  `Status` varchar(100) NOT NULL,
  `Currency` varchar(10) NOT NULL,
  `Credits` varchar(10) NOT NULL,
  `Promo_Code` varchar(100) NOT NULL,
  `Promo_Discount` varchar(100) NOT NULL,
  `Channel` varchar(100) NOT NULL,
  `Place_of_Supply` varchar(255) NOT NULL,
  `Items` varchar(500) NOT NULL,
  `Order_Id` varchar(100) NOT NULL,
  `Payment_Mode` varchar(100) NOT NULL,
  `Invoice_No` varchar(50) NOT NULL,
  `Learner_GST` varchar(50) NOT NULL,
  `Affiliate_Code` varchar(50) NOT NULL,
  `GSTIN` varchar(50) NOT NULL,
  `Taxable_Value` varchar(50) NOT NULL,
  `Country_Code` varchar(50) NOT NULL,
  `IGST` varchar(10) NOT NULL,
  `CGST` varchar(10) NOT NULL,
  `SGST` varchar(10) NOT NULL,
  `VAT` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `8dw_m_answers`
--
ALTER TABLE `8dw_m_answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `8dw_m_questions`
--
ALTER TABLE `8dw_m_questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lms_data`
--
ALTER TABLE `lms_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_user_data`
--
ALTER TABLE `master_user_data`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`,`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `8dw_m_answers`
--
ALTER TABLE `8dw_m_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `8dw_m_questions`
--
ALTER TABLE `8dw_m_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `lms_data`
--
ALTER TABLE `lms_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=424;

--
-- AUTO_INCREMENT for table `master_user_data`
--
ALTER TABLE `master_user_data`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
