<?php

session_start();
if (isset($_SESSION['username'])) {
    # code...
    // Connect Database
    $mysql = mysqli_connect("localhost", "root", "", "8dw") or die(mysqli_connect_error());

    mysqli_select_db($mysql, '8dw') or die("Sorry No Database ");


    $rel = mysqli_query($mysql, "select * from master_user_data");
}

$quesa = mysqli_query($mysql, "Update master_user_data set Department_Code='".$_POST['value']."' where id='".$_POST['pid']."'");
if ($quesa) {
    # code...
    $q = mysqli_query($mysql, "select * from master_user_data where id='".$_POST['pid']."'");
    $data = mysqli_fetch_assoc($quesa);
    echo $data['Department_Code'];
}
